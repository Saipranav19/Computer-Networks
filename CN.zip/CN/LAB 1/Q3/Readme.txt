Lab1-Q3:

The commands for compiling the program are:
Server : python3 Server.py
Client : python3 Client.py

# In this case Server keeps running until closed by the user but the client needs to be compiled everytime for a new input.

After compiling the program, the client asks for the input(filename and number of bytes to be copied), then the client sends the input to the server.

> If the file is present, then the server sends the N bytes to the client.
> Or else the server sends 'SORRY' to the client.

>If client receives the bytes but if  'filename1' is missing then it prints "Server says that the file doesn't exist".

>If the user gives "Quit" as the input then both the server and the client terminates.

>If the program gets any input other than these, then the program asks for the correct inputs.