import socket
from pathlib import Path

host=socket.gethostname()

Clientsocket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
Clientsocket.connect((host,7001))

msg=input("Enter the filename and the number of bytes: ")

Clientsocket.sendall(msg.encode()) 

temp=Clientsocket.recv(4096).decode()

if temp=="Give proper inputs!":
     print("Give proper inputs!")
elif temp=="Quit":
    print("Server Exited!")
    print('Program Terminated')
elif temp=="SORRY!":
     print("Server says Sorry!")
     print("File missing!")
else:
    path=Path('./filename1.txt')
    boo=path.is_file()

    if boo==True:
        f=open("filename1.txt","w+")
        f.write(temp)
        print("Bytes received and written to file")
    else:
        print("Server says that the file does not exist") 

Clientsocket.close()