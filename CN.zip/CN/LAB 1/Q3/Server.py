import socket

host=socket.gethostname()

Serversocket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
Serversocket.bind((host,7001))

Serversocket.listen(3)

while True:
    
    conn,addr=Serversocket.accept()

    try:
        msg=conn.recv(4096)
        if not msg:
            continue
    except ConnectionAbortedError as e:
        print(str(e))
        break

    V=msg.decode().split()

    try:
        N=int(V[1])
        filename=V[0]     
    except IndexError as ie:
        P="Give proper inputs!"
        if V[0]=="Quit":
            print("Program says Quit!")
            print("Server aborted")
            conn.send(V[0].encode())
            break
        else:
         print(P)
         conn.send(P.encode())
         continue

    try:
        f=open(filename,"r")
        temp=f.read()[-N:]

        conn.sendall(temp.encode())
        print("Bytes Sent!!")
        
    except FileNotFoundError as e:
        Q="SORRY!"
        print("SORRY!")
        conn.sendall(Q.encode())
     
conn.close()
