Lab1-Q1:

The commands for compiling the program are:
Server : python3 Server.py
Client : python3 Client.py

After compiling both the programs, the client program asks for input that needs to be echoed or 'Quit for exiting the program.

After entering the input the client sends the message to server and server prints the received msg and sends it back to the client. Client prints the message received from the server.

If the user enters 'Quit', then both Server and Client terminates.