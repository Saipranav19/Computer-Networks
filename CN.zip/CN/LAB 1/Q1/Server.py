import socket

buffer_size=4096

Serversocket=socket.socket(socket.AF_INET, socket.SOCK_DGRAM);
# datagram socket

Serversocket.bind(("127.0.0.1",6969))
#binding

while(True):
  msg,addr=Serversocket.recvfrom(buffer_size)
 
  print("Msg received:",msg.decode())
  
  if msg.decode()=="Quit":
   print("Program says Quit!")
   break
  
  Serversocket.sendto(msg,addr)

  print("Msg sent:",msg.decode())
  print()

Serversocket.close()