import socket

Clientsocket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

print("Enter 'Quit' to exit the program")

while True:

 msg=input("Enter the msg: ") 

 addressport=("127.0.0.1",6969)
 Clientsocket.sendto(msg.encode(),addressport)

 if msg=="Quit":
  print("Program says Quit!")
  break
 else :
  reply,addr=Clientsocket.recvfrom(4096)

  print("Msg from Server:",reply.decode())
  print()

Clientsocket.close()