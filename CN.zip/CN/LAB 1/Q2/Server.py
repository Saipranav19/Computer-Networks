import socket
import math

buffer_size=4096

Serversocket=socket.socket(socket.AF_INET, socket.SOCK_DGRAM);
# datagram socket

Serversocket.bind(("127.0.0.1",7000))
#binding

while(True):
  msg,addr=Serversocket.recvfrom(buffer_size)

  print("Operation received: {}".format(msg.decode()))
   
  temp=msg.decode()
  V=temp.split()
  op=V[0]
  if op=="Quit":
   print("Program Says Quit!")
   Serversocket.sendto(op.encode(),addr)
   break
  
  temp=0

  if len(V)!=3:
    print("Enter correct commands!")
    temp+=1
  elif op=="add":
      x=int(V[1])
      y=int(V[2])
      ans=x+y
  elif op=="mul":
      x=int(V[1])
      y=int(V[2])
      ans=x*y 
  elif op=="mod":
      x=int(V[1])
      y=int(V[2])
      ans=x%y
  elif op=="hyp":
      x=int(V[1])
      y=int(V[2])
      ans=int(math.sqrt(x*x+y*y))
  else:
     print("Enter correct commands!")
     temp+=1
 
  if temp>0:
    conv="Wrong"
    Serversocket.sendto(conv.encode(),addr)
  else:
    conv=str(ans)
    Serversocket.sendto(conv.encode(),addr)

Serversocket.close() 