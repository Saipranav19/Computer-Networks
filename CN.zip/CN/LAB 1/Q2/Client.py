import socket

Clientsocket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

print("Enter 'Quit' to exit the program")

while(True):

 msg=input("Enter the Command: ")

 encodedmsg=str.encode(msg)
 addressport=("127.0.0.1",7000)
 Clientsocket.sendto(encodedmsg,addressport)

 reply,addr=Clientsocket.recvfrom(4096)
 
 if reply.decode()=="Wrong":
    print("Enter correct commands!")
 elif reply.decode()=="Quit":
    print("Program says Quit!")
    break
 else:
    print("Answer from Server: {}".format(reply.decode()))

Clientsocket.close()