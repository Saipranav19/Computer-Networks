Lab1-Q2:

The commands for compiling the program are:
Server : python3 Server.py
Client : python3 Client.py

After compiling the program, the client asks for commands, if the user gives the commands other than the specified commands then it asks for proper commands.

The specfied commands are:

add op1 op2
mul op1 op2
mod op1 op2
hyp op1 op2

Then the server commputes the operation sent and sends the answer to the client and client prints it.

#return value is an integer.

If the user gives 'Quit' as the input then both the server and the client terminates.