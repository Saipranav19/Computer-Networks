import random

with open("infile.txt",'w+') as input_file:
    for i in range(55):
        data = ''.join(str(random.randint(0, 1)) for _ in range(128))

        input_file.write(f'{data}\n')
print("Inputs created and written to infile.txt")
input_file.close()