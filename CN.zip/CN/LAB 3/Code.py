######################

# NAME: Kodari Saipranav Reddy
# Roll Number: CS20B040
# Course: CS3205 Jan. 2023 semester
# Lab number: 3
# Date of submission: Mar 15,2023
# I confirm that the source file is entirely written by me without
# resorting to any dishonest means.
# Website(s) that I used for basic socket programming code are:
# URL(s): NA

########################

import sys
import random

def CRC(input_data):
   divisor='100000111'
   # Crc-8 : x^8 + x^2 + x + 1
   input_data=input_data+"00000000"
   checksum=''
   # initiating the values and appending len(divisor)-1 number of zeros to input data

   temp=input_data[0:9]
   # copying first 9 values of input data into temp and then modifying temp after every iteration

   for i in range(0,len(input_data)-8,1):
      if i>0:
         temp=temp[1:9]+input_data[i+8]
         # updating the temp 
      if temp[0]=='1':
         temp= bin(int(temp,2) ^ int(divisor,2))[2:].zfill(9)
         # calculating the xor between divisor and temp then modifying it to become bit string of length 9 
         if i==(len(input_data)-9): 
            checksum=temp[1:]    
         # If that's the last iteration then updating the checksum value
      else:
         if i==(len(input_data)-9) :
            checksum=temp[1:]
         # Similarly again if that's the last iteration then updating the checksum value
   return checksum

def check(msg,div):

   checksum=''

   temp=msg[0:9]

   for i in range(0,len(msg)-8,1):
      if i>0:
         temp=temp[1:9]+msg[i+8]
      if temp[0]=='1':
         temp= bin(int(temp,2) ^ int(div,2))[2:].zfill(9)
         if i==(len(msg)-9): 
            checksum=temp[1:]    
      else:
         if i==(len(msg)-9) :
            checksum=temp[1:]

   if checksum=="00000000":
      return 1
   # No error detected
   else : return 0
   # else failed

def main():

   filename=sys.argv[1]
   # taking input file

   with open(filename, "r") as input_file, open("outfile", "w") as output_file:
      for line in input_file:
         divisor='100000111'
         line = line.strip()
         output_file.write(f'\nOriginal String: {line}\n')
         checksum = CRC(line)
         Tr=line+checksum
         # Original message with Crc
         output_file.write(f'Original String with CRC: {Tr}\n')
         # updating the output file
         
         # Random bit errors
         output_file.write("\n**************Random Bit Errors****************\n\n")
         for j in range(10):
               odd_no=random.randint(3,136)
               data=Tr
               for k in range(odd_no):
                  m=random.randint(0,100000)%135
                  data=data[:m] + str(1-int(data[m])) + data[m+1:]
               # generating odd number and flipping that many number of bits   
               output_file.write(f'Corrupted String: {data}\n')
      
               output_file.write(f'Number of Errors Introduced: {odd_no}\n')
               
               num=check(data,divisor)
               if num==0:
                  output_file.write(f'CRC Check : Failed\n\n')
                  # If number of ones are zero then CRC check failed else passed
               else :
                  output_file.write(f'CRC Check : Passed\n\n')
         
         # Bursty Errors
         output_file.write("****************Bursty Errors*******************\n\n")
         for j in range(5):
            bursty_no=random.randint(101,109)
            data=Tr
            for k in range(6):
               n=bursty_no+k
               data=data[:n] + str(1-int(data[n])) + data[n+1:]
            # generating a bursty number and flipping the next consecutive six bits
            output_file.write(f'Corrupted String: {data}\n')

            output_file.write(f'Number of Errors Introduced: 6\n')

            num=check(data,divisor)
            if num==0:
               output_file.write(f'CRC Check : Failed\n\n')
               # If equal then failed else passed
            else :
               output_file.write(f'CRC Check : Passed\n\n')
         output_file.write("****************************************************************************")
   input_file.close()
   output_file.close()
   # closing the opened files

   print("Inputs taken from infile.txt and outputs are written to the output file")

if __name__=="__main__":
   main()