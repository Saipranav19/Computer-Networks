Lab 3:

The commands for compiling the program are :
 
  So at first we start the script file and then the recording will be started
         --- script script_file.txt
  Then we will run the create_input file for generating random inputs which will be written in the infile
         --- python3 create_input.py
  Then we run our main code file 
         --- python3 Code.py infile.txt

So upon compiling the program, It takes the input from the infile and it will write the Outputs such as the Original String with CRC and Error Detection tests in the output file.