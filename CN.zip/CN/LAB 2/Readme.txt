Lab 2:

The commands for compiling the program are:

 So at first we will start the script and it would start recording that would  
 be done in terminal
        -- script script_file.txt
 Then for running the code 
        -- Client_Server.py startportnumber input_file

So upon compiling the program, It asks for the input i.e domain name which is in the format xxx.yyy.zzz.
If any of the given input is not in that format then it asks for the user to give the correct inputs.
If the given input domain name is present in the given input file it gives the respective domain name or else it would print "Not Found".
If the user enters bye then every server gets closed and every child program gets terminated.

The querys and the responses of each server through out the given inputs are stored in their respective output files.
