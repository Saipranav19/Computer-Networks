//////////////////////////

// NAME: Kodari Saipranav Reddy
// Roll Number: CS20B040
// Course: CS3205 Jan. 2023 semester
// Lab number: 3
// Date of submission: Apr 5,2023
// I confirm that the source file is entirely written by me without
// resorting to any dishonest means.
// Website(s) that I used for basic socket programming code are:
// URL(s): NA

///////////////////////////

// Client Process

#include <bits/stdc++.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <chrono>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
using namespace std;

typedef long long int ll;

struct Packet
{
    char seqNum;
    char *data;
    int retransmission = 0;
};
// Packet

int sockfd;
struct sockaddr_in Reciever_addr;
int N = 0;
int max_retrans = 0;

int debug = 0;
string recvr_name;
int recvr_portno;
int pkt_length;
int pkt_genrate;
int max_pkts;
int window_size;
int max_buffersize;

vector<struct Packet> pkt_buffer;
vector<struct Packet> Window;
// initialising the variables and the vectors required.

void pkt_generation()
{
    // pkt_genrate = packets per second
    // max_buffersize = number of packets
    int seq_num = 0;
    while (N < max_pkts && max_retrans < 5)
    {
        if (seq_num > 255)
            seq_num = 0;
        if (pkt_buffer.size() < max_buffersize)
        {
            Packet packet;
            packet.seqNum = seq_num;
            packet.data = new char[pkt_length];
            pkt_buffer.push_back(packet);
            N++;
            seq_num++;
            // creating packets and adding them to the packet buffer
        }
        // then sleep for the given time
        this_thread::sleep_for(chrono::milliseconds(1000 / pkt_genrate));
    }
}

map<char, ll> send_time;
map<char, ll> received_time;
map<char, ll> RTT;
// global maps

void send_pkts()
{
    for (int i = 0; i < window_size; i++)
    {
        send_time[Window[i].seqNum] = chrono::duration_cast<chrono::microseconds>(chrono::system_clock::now().time_since_epoch()).count();
        Window[i].retransmission++;

        // Send the message to server:
        Packet client_msg = Window[i];
        if (sendto(sockfd, &client_msg, sizeof(client_msg), 0, (struct sockaddr *)&Reciever_addr, sizeof(Reciever_addr)) < 0)
        {
            cout << "Unable to send message at sequence number:" << Window[i].seqNum << endl;
        }
    }
    // Sending the packets in the window buffer to the Receiver.
}

int timeout = 0, pkt_drop = 0;
int retransmission_num = 0;

void my_send()
{
    int i = 0;
    while (N < max_pkts && Window.size() > 0 && max_retrans < 5)
    {
        sleep(3);
        if (i == 0 || timeout > 0 || pkt_drop > 0)
        {
            send_pkts();
            if (timeout > 0)
            {
                timeout = 0;
                retransmission_num += window_size;
            }
            else if (pkt_drop > 0)
            {
                pkt_drop = 0;
                retransmission_num += window_size;
            }
        }
        i++;
    }
    // In the conditions of timeout and packet drop then we have to send the packets in the window again.
}
int succes = 0;
float RTT_avg = 0;

void recv_pkts()
{
    Packet buffer, temp_buffer;
    socklen_t addr_len = sizeof(Reciever_addr);

    while (N <= max_pkts)
    {
        int bytes_received = recvfrom(sockfd, &buffer, sizeof(buffer), MSG_WAITALL, (struct sockaddr *)&Reciever_addr, &addr_len);
        // receiving the ACK values
        max_retrans = Window[0].retransmission;
        if (Window[0].retransmission > 5)
            break;
        // If number of retransmissions are greater than 5 then break.

        if (bytes_received < 0)
        {
            cerr << "Error receiving message" << endl;
            return;
        }
        else
        {
            if (Window[0].seqNum == buffer.seqNum)
            {
                received_time[Window[0].seqNum] = chrono::duration_cast<chrono::microseconds>(chrono::system_clock::now().time_since_epoch()).count();
                RTT[Window[0].seqNum] = received_time[Window[0].seqNum] - send_time[Window[0].seqNum];

                RTT_avg = (RTT_avg * (RTT.size() - 1) + RTT[Window[0].seqNum]) / RTT.size();
                // If the recevied ACK and the packet have the same seq num then update the new variables and send the new packet in the window.

                Packet msg = pkt_buffer[0];
                if (sendto(sockfd, &msg, sizeof(msg), 0, (struct sockaddr *)&Reciever_addr, sizeof(Reciever_addr)) < 0)
                {
                    cout << "Unable to send message at sequence number:" << pkt_buffer[0].seqNum << endl;
                }
                // sending the new packet

                Window.erase(Window.begin());
                Window.push_back(pkt_buffer[0]);
                pkt_buffer.erase(pkt_buffer.begin());
                succes++;
                // changing the windoe and the packet buffers.

                if (debug > 0)
                {
                    cout << Window[0].seqNum << "             " << send_time[Window[0].seqNum] << "             " << Window[0].retransmission << endl;
                }
                // If debug then print extra variables
            }
            // success
            else
            {
                pkt_drop++;
                for (int i = Window[0].seqNum; i < Window[0].seqNum + window_size; i++)
                {
                    int tbytes_received = recvfrom(sockfd, &temp_buffer, sizeof(temp_buffer), 0, (struct sockaddr *)&Reciever_addr, &addr_len);

                    if (tbytes_received < 0)
                    {
                        cerr << "Error receiving message" << endl;
                        return;
                    }
                }
                // If not then send the packets in the window again.
            }
            // Pkt loss case
        }
    }
}

void tmer()
{

    while (N <= max_pkts)
    {
        Packet temp_buffer;
        socklen_t addr_len = sizeof(Reciever_addr);

        auto start = send_time[0];
        if (Window[0].retransmission > 5)
            break;
        // If number of retransmissions are greater than 5 then exit the program
        while (1)
        {
            if (succes > 0)
            {
                succes = 0;
                break;
            }
            ll mid = chrono::duration_cast<chrono::microseconds>(chrono::system_clock::now().time_since_epoch()).count();
            int timeout_const;

            timeout_const = 100;
            if (RTT.size() >= 10)
                timeout_const = 2 * RTT_avg / 1000;
            // We will keep checking the time difference until the packet is reached.

            if ((mid - start) / 1000 > timeout_const)
            {
                timeout++;
                for (int i = 0; i < window_size; i++)
                {
                    int tbytes_received = recvfrom(sockfd, &temp_buffer, sizeof(temp_buffer), 0, (struct sockaddr *)&Reciever_addr, &addr_len);

                    if (tbytes_received < 0)
                    {
                        cerr << "Error receiving message" << endl;
                        return;
                    }
                }
                // If timeout- yes, then increase the timeout variable and send the packets again.
            }
            // timeout case
        }
    }
}

int main(int argc, char *argv[])
{
    
    for(int i=1; i < argc; i+=2)
    {
        string str = argv[i];
        if(str == "-d") debug = atoi(argv[i+1]);
        else if (str == "-s")
            recvr_name = argv[i + 1];
        else if (str == "-p")
            recvr_portno = atoi(argv[i + 1]);
        else if (str == "-l")
            pkt_length = atoi(argv[i + 1]);
        else if (str == "-r")
            pkt_genrate = atoi(argv[i + 1]);
        else if (str == "-n")
            max_pkts = atoi(argv[i + 1]);
        else if (str == "-w")
            window_size = atoi(argv[i + 1]);
        else if (str == "-f")
            max_buffersize = atoi(argv[i + 1]);
        else
        {
            cout << "Arguments doesn't match the command line options!!";
            exit(EXIT_FAILURE);
        }
    }
    // Taking the command level inputs and storing them in the defined variables.

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
    {
        cout << "Socket creation failed!\n";
        exit(EXIT_FAILURE);
    }
    // Creating socket

    memset(&Reciever_addr, 0, sizeof(Reciever_addr));
    Reciever_addr.sin_family = AF_INET;
    Reciever_addr.sin_port = htons(recvr_portno);
    // initialising the variables.

    for (int i = 0; i < window_size; i++)
    {
        Window.push_back(pkt_buffer[0]);
        pkt_buffer.erase(pkt_buffer.begin());
    }
    // initiaising window vector

    thread t1(pkt_generation);
    thread t2(my_send);
    thread t3(recv_pkts);
    thread t4(tmer);
    // Creating threads one for each functions

    t1.join();
    t2.join();
    t3.join();
    t4.join();
    // joining the threads.

    if (debug > 0)
        cout << " Seq Number "
             << "             "
             << "Time Generated"
             << "             "
             << "Number of attempts" << endl;
    cout << "Packet Generation Rate : " << pkt_genrate << endl;
    cout << "Packet Length : " << pkt_length << endl;

    float ans = retransmission_num / N;
    cout << "Retransmission Ratio : " << ans << endl;
    // printing the variables.

    int sum = 0;
    float avg = 0;

    for (auto val : RTT)
    {
        sum += val.second;
    }

    avg = sum / RTT.size();

    cout << "Average RTT values of all acknowldged packets : " << avg << endl;
    // printing the average RTT values

    return 0;
}
