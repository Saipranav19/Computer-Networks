//////////////////////////

// NAME: Kodari Saipranav Reddy
// Roll Number: CS20B040
// Course: CS3205 Jan. 2023 semester
// Lab number: 3
// Date of submission: Apr 5,2023
// I confirm that the source file is entirely written by me without
// resorting to any dishonest means.
// Website(s) that I used for basic socket programming code are:
// URL(s): NA

///////////////////////////

// Server Process

#include <bits/stdc++.h>
#include <thread>
#include <sys/types.h>
#include <chrono>
#include <random>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
using namespace std;

typedef long long int ll;

struct Packet
{
    char seqNum;
    char *data;
};
// Packet

struct ACK
{
    char seqNum;
};
// ACK

int main(int argc, char *argv[])
{
    int debug = 0;
    int port_num;
    int max_pkts;
    float pkt_error_rate;

    for(int i=1;i < argc ;i+=2)
    {
        string str = argv[i];
        if(str == "-d") debug = atoi(argv[i+1]);
        else if (str == "-p")
            port_num = atoi(argv[i + 1]);
        else if (str == "-n")
            max_pkts = atoi(argv[i + 1]);
        else if (str == "-e")
            pkt_error_rate = atof(argv[i + 1]);
        else
        {
            cout << "Arguments doesn't match the given command line options!!" << endl;
            exit(EXIT_FAILURE);
        }

    }

    
    // storing the command line inputs in the respective variables

    int sockfd;
    Packet buffer;
    struct sockaddr_in servaddr, clienaddr;
    socklen_t len = sizeof(clienaddr);
    // initialising the socket variables.

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
    {
        cout << "Socket Creation Failed!\n";
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    memset(&clienaddr, 0, sizeof(clienaddr));
    // creating and initialising the socket variables
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(port_num);

    if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("Bind Failure!");
        exit(EXIT_FAILURE);
    }
    // binding the socket

    int N = 0;
    char NFE = 0;
    len = sizeof(clienaddr);

    int num = 1 / pkt_error_rate;
    vector<int> drop;
    if (max_pkts > num)
    {
        for (int i = 0; i < max_pkts - num; i += num)
        {
            int x = i + (rand() % (num + 1));
            drop.push_back(x);
        }
    }
    else
    {
        int x = 0 + (rand() % (num + 1));
        drop.push_back(x);
    }
    // adding the number of packets to be dropped based on the drop probability into a vector.

    while (N <= max_pkts)
    {
        int pkt_drop = 0;
        for (int i = 0; i < drop.size(); i++)
        {
            if (N == drop[i])
            {
                pkt_drop++;
            }
        }
        // dropping the respective packets

        if (NFE > 255)
            NFE = 0;
        // Max value of NFE is 255

        int num_of_bytes = recvfrom(sockfd, &buffer, sizeof(buffer), MSG_WAITALL, (struct sockaddr *)&clienaddr, &len);
        // recv the packet

        ll current = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();

        if (buffer.seqNum == NFE && pkt_drop == 0)
        {
            ACK K;
            K.seqNum = NFE;

            NFE++;
            N++;
            sendto(sockfd, &K, sizeof(K), 0, (const struct sockaddr *)&clienaddr, len);
            if (debug == 0)
            {
                cout << "Seq # :" << buffer.seqNum << endl;
                cout << "Time Received : " << current / 1000 << ":" << current % 1000 << endl;
                cout << "Packet Dropped = False " << endl;
            }
        }
        // if the NFE and the incoming packet seq Num are equal then send the ack and increase the NFE.
        else
        {
            // packet drop
            // send the prev ack
            ACK K;
            K.seqNum = NFE; // patha NFE maraledu kabatti

            sendto(sockfd, &K, sizeof(K), 0, (const struct sockaddr *)&clienaddr, len);
            cout << "Seq # :" << buffer.seqNum << endl;
            cout << "Time Received : " << current / 1000 << ":" << current % 1000 << endl;
            cout << "Packet Dropped = True " << endl;
        }
        // If they are not equal or the packet is dropped due to errors then send the previous ACK.
    }
    return 0;
}