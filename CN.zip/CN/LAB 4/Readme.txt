Lab 4:

The commands for compiling the program are:

   Start the recording of the script file
     ----- script script_file.txt
   Then for running the Receiver file i.e the Server
     ----- g++ Receiver.cpp -p 12345 -n 400 -e 0.00001 
   Then we will run the Client i.e the Sender program
     ----- g++ Sender.cpp -s machine1 -c1 -p 12345 -l 512 -r 10 -n 400 -w 3 -b 10

So upon compiling the program, it takes the command line inputs as mentioned above and prints the packet transmission rate, drop prob, length, packet retransmission rate and the average of the RTT values of all the acknowledged packets.
The report contians the avg RTT values and the retransmission rate of the acknowledged packets for different packet drop rates.
