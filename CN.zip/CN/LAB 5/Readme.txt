Lab 5 :

The commands for compiling the program are :

   At first, we start the script file and the recording will be started 
            ---- script script_file.txt
   Then we will run the main program 
            ---- python3 main.py -i id -f infile -o outfile -h hi -a lsai -s spfi

So, after compiling the main program, it prints the adjacency matrix of max and min costs from the inputfile, then all threads get started for sending hello, helloreply, lsa and then, it computes the shortest path frame and the prints the Routing Table of the node identifier at different time instances in the outfile.

Only the respective Node i's Routing Table is printed in the Output file i 